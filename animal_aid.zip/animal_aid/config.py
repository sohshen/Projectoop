import os
from flask_uploads import configure_uploads, IMAGES
class Config:
    SECRET_KEY = 'you-can-put-any-random-string-here'
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:123456@localhost/animal_aid_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    basedir = os.path.abspath(os.path.dirname(__file__))  # 获取当前文件的绝对路径
    UPLOADED_PHOTOS_DEST = os.path.join(basedir, 'static/uploads') # 设置上传目录
    UPLOAD_SET = {'photos': IMAGES}  # 定义上传集
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('chooseImagesBtn').addEventListener('click', function() {
        document.getElementById('imageInput').click();
    });

    document.getElementById('imageInput').addEventListener('change', function() {
        var imagePreview = document.getElementById('imagePreviewContainer');
        imagePreview.innerHTML = '';

        for (var i = 0; i < this.files.length; i++) {
            var file = this.files[i];
            var reader = new FileReader();

            reader.onload = function(e) {
                var img = document.createElement('img');
                img.src = e.target.result;
                img.style.width = '130px'; // 限制预览图像的最大宽度
                img.style.padding = '5px'; // 添加间距\
                img.style.height = 'auto';
                imagePreview.appendChild(img);
            };

            reader.readAsDataURL(file);
        }
    });
});


let map; // 将地图对象提升到函数外部，以便在其他地方复用

function initMap(latitude, longitude) {
    if (map) {
        map.remove(); // 如果地图已经初始化，先移除当前地图
    }
    map = L.map('map').setView([latitude, longitude], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([latitude, longitude]).addTo(map)
        .bindPopup('Your current location')
        .openPopup();
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            // 成功获取位置
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            // 设置表单中的纬度和经度值
            document.getElementsByName('latitude')[0].value = latitude;
            document.getElementsByName('longitude')[0].value = longitude;

            // 初始化地图并设置当前位置
            initMap(latitude, longitude);

            // 获取附近的动物救援帖子
            $.getJSON('/nearby_posts', { latitude: latitude, longitude: longitude }, function(data) {
                // 处理获取到的帖子数据
                console.log(data); // 用于调试，显示获取到的数据
                // 你可以将数据展示在页面上，或者用其他方式处理
            });
        }, function(error) {
            // 处理位置获取错误
            alert('无法获取当前位置。请检查您的浏览器权限设置。');
            console.error('Geolocation error:', error);
        }, {
            // 设置位置获取的选项
            enableHighAccuracy: true, // 使用高精度
            timeout: 5000, // 设置超时时间（5秒）
            maximumAge: 0 // 不使用缓存的地理位置
        });
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}



let currentImages = [];
let currentIndex = 0;

function openModal(postId) {
    $.ajax({
        url: '/post/' + postId,
        method: 'GET',
        success: function(data) {
            $('#modal-title').text(data.title);
            $('#modal-description').text(data.description);
            $('#modal-address').text(data.address);
            currentImages = data.images; // 直接使用图像URL数组
            currentIndex = 0;
            displayImage();
            showMap(data.latitude, data.longitude);

            $('#approve-btn').off('click').on('click', function() { approvePost(postId); });
            $('#reject-btn').off('click').on('click', function() { rejectPost(postId); });

            document.getElementById('postModal').style.display = 'block';
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('获取帖子(ID ' + postId + ')时出错：', textStatus, errorThrown, jqXHR.responseText); // 更详细的错误信息
        }
    });
}

function displayImage() {
    if (currentImages.length > 0) {
        $('#modal-images').html('<img src="' + currentImages[currentIndex] + '" alt="Post Image">');
    } else {
        $('#modal-images').html('<p>没有可用的图片。</p>');
    }
}

function prevImage() {
    if (currentIndex > 0) {
        currentIndex--;
        displayImage();
    }
}

function nextImage() {
    if (currentIndex < currentImages.length - 1) {
        currentIndex++;
        displayImage();
    }
}

function showMap(latitude, longitude) {
    var map = L.map('modal-map').setView([latitude, longitude], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([latitude, longitude]).addTo(map)
        .bindPopup('Location')
        .openPopup();
}

function approvePost(postId) {
    $.ajax({
        url: '/approve/' + postId,
        method: 'POST',
        success: function() {
            closeModal();
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('Error approving post:', textStatus, errorThrown);
        }
    });
}

function rejectPost(postId) {
    $.ajax({
        url: '/delete/' + postId,
        method: 'POST',
        success: function() {
            closeModal();
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('Error rejecting post:', textStatus, errorThrown);
        }
    });
}


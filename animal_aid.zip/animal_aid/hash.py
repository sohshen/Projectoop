from werkzeug.security import generate_password_hash

password = '223344'  # 你的管理员密码
hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
print(hashed_password)

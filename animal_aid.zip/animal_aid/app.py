from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, abort
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import HiddenField, StringField, TextAreaField, FloatField, PasswordField, SelectField, FileField, BooleanField
from wtforms.validators import DataRequired, Length, EqualTo
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from PIL import Image
from config import Config
from flask_login import current_user, login_required, login_user, logout_user, LoginManager, UserMixin
from flask_wtf.file import FileAllowed, FileRequired
from functools import wraps
from sqlalchemy import func
from geopy.distance import geodesic
from datetime import datetime, timezone
import uuid
import os

# 定义装饰器确保管理员权限
def admin_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            abort(403)  # 无权限
        return func(*args, **kwargs)
    return decorated_view

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)


login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 模型
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')  # user, volunteer, admin
    phone_number = db.Column(db.String(20), nullable=False)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    last_online = db.Column(db.DateTime, default=datetime.utcnow)
    real_name = db.Column(db.String(20), nullable=False)

    # Flask-Login 的要求已经由 UserMixin 实现，不需要手动定义这些方法
class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)
    description = db.Column(db.Text, nullable=False)
    address = db.Column(db.String(255))
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    approved = db.Column(db.Integer, default=0) 
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), server_onupdate=db.func.now())
    images = db.Column(db.Text, nullable=True)  # 以逗号分隔的图像文件名字符串
    name = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=False)


    def to_dict(self):
        return {
            'name': self.name,
            'phone': self.phone,
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'images': self.images,
            'created_at': self.created_at
        }

class VolunteerApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    real_name = db.Column(db.String(100), nullable=False)
    id_card_image = db.Column(db.String(100), nullable=False)
    selfie_image = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), default='Pending')  # 默认状态为'Pending'

    user = db.relationship('User', backref='volunteer_applications')

# 表单
class PostForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    title = StringField('Title', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    latitude = HiddenField('Latitude')  # 将字段类型更改为 HiddenField
    longitude = HiddenField('Longitude')  # 将字段类型更改为 HiddenField

class RegistrationForm(FlaskForm):
    username = StringField('username', validators=[DataRequired(), Length(min=4, max=25)])
    email = StringField('email', validators=[DataRequired(), Length(min=6, max=35)])
    password = PasswordField('password', validators=[DataRequired(), Length(min=6, max=35)])
    confirm_password = PasswordField('repeat password', validators=[DataRequired(), EqualTo('password', message='密码必须匹配')])

class LoginForm(FlaskForm):
    username = StringField('username', validators=[DataRequired()])
    password = PasswordField('password', validators=[DataRequired()])
    remember_me = BooleanField('remember me') 

class VolunteerForm(FlaskForm):
    real_name = StringField('identity name', validators=[DataRequired(), Length(min=2, max=100)])
    id_card_image = FileField('identity picture(jpg,png only)', validators=[DataRequired()])  # 移除 FileAllowed
    selfie_image = FileField('selfie picture(jpg,png only)', validators=[DataRequired()])  # 移除 FileAllowed
    address = StringField('address', validators=[DataRequired(), Length(min=5, max=200)])
    phone_number = StringField('phone number', validators=[DataRequired(), Length(min=8, max=20)])



class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)   
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f'<Contact {self.name}>'

class RescueReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    injured_part = db.Column(db.String(255), nullable=False)
    rescue_method = db.Column(db.String(255), nullable=False)
    after_rescuing = db.Column(db.String(255), nullable=False)
    process = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    images = db.Column(db.Text, nullable=True)  # 以逗号分隔的图像文件名字符串
    title = db.Column(db.String(200))
    name = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=False)

    def to_dict(self):
        return {
            'name': self.name,
            'phone': self.phone,
            'id': self.id,
            'injured_part': self.injured_part,
            'rescue_method': self.rescue_method,
            'after_rescuing': self.after_rescuing,
            'process': self.process,
            'images': self.images,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }


@app.route('/')
def index():
    basic_info = {"title": "Animal Aid - 首页", "description": "欢迎来到动物援助网站"}

    if current_user.is_authenticated and current_user.role == 'volunteer':
        latitude = current_user.latitude
        longitude = current_user.longitude

        print(f"Current User Latitude: {latitude}, Longitude: {longitude}")
        
        if latitude is not None and longitude is not None:
            posts = Post.query.filter_by(approved=True).order_by(
                func.abs(Post.latitude - latitude) + func.abs(Post.longitude - longitude)
            ).limit(10).all()
        else:
            posts = Post.query.filter_by(approved=True).order_by(Post.created_at.desc()).limit(5).all()
    else:
        posts = Post.query.filter_by(approved=True).order_by(Post.created_at.desc()).limit(5).all()

    print(f"Number of posts retrieved: {len(posts)}")
    return render_template('index.html', posts=posts, current_user=current_user, basic_info=basic_info)



@app.route('/update_location', methods=['POST'])
@login_required
def update_location():
    data = request.get_json()
    latitude = data.get('latitude')
    longitude = data.get('longitude')

    if current_user.role == 'volunteer':
        current_user.latitude = latitude
        current_user.longitude = longitude
        db.session.commit()
        return jsonify(success=True)
    return jsonify(success=False)


@app.route('/get_posts_for_volunteer')
@login_required
def get_posts_for_volunteer():
    user = User.query.get(current_user.id)
    user_location = (user.latitude, user.longitude)
    
    posts = Post.query.filter_by(approved=True).all()
    posts_with_distance = []
    
    for post in posts:
        post_location = (post.latitude, post.longitude)
        distance = geodesic(user_location, post_location).km
        posts_with_distance.append((post, distance))
    
    # 按距离排序
    posts_with_distance.sort(key=lambda x: x[1])
    
    # 获取最近的帖子
    closest_posts = [post for post, _ in posts_with_distance[:10]]
    
    return jsonify({
        'posts': [{
            'id': post.id,
            'title': post.title,
            'description': post.description,
            'images': post.images.split(','),
            'latitude': post.latitude,
            'longitude': post.longitude
        } for post in closest_posts]
    })

@app.route('/user_management')
def user_management():
    users = User.query.all()
    return render_template('user_management.html', users=users)

@app.route('/admin/admin_index')
def admin_index():
    if 'role' not in session or session['role'] != 'admin':  # Only admin can access
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))

    # Query for unapproved posts
    posts = Post.query.filter_by(approved=True).all()
    
    # Query for all users if needed
    users = User.query.all()  # Assuming you have a User model

    return render_template('admin_index.html', posts=posts, users=users)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        # 检查用户名是否已存在
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('user existed', 'danger')
        else:
            # 检查电子邮件是否已存在
            existing_email = User.query.filter_by(email=form.email.data).first()
            if existing_email:
                flash('email existed。', 'danger')
            else:
                # 创建新用户并保存到数据库
                hashed_password = generate_password_hash(form.password.data, method='pbkdf2:sha256')
                new_user = User(
                    username=form.username.data, 
                    email=form.email.data, 
                    password=hashed_password,

                )
                db.session.add(new_user)
                db.session.commit()
                flash('registration sucessfull！', 'success')
                return redirect(url_for('login'))
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            remember = form.remember_me.data  # 获取 remember_me 选项的值
            login_user(user, remember=remember)  # 传递 remember 选项
            
            session['role'] = user.role  # 设置用户角色
            
            # 更新 last_online 字段
            user.last_online = datetime.now()
            db.session.commit()
            
            flash('登录成功！', 'success')
            if user.role == 'admin':
                return redirect(url_for('admin_posts'))
            elif user.role == 'volunteer':
                return redirect(url_for('index'))
            else:
                return redirect(url_for('index'))
        else:
            flash('登录失败，请检查用户名和密码。', 'danger')
    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('您已成功登出。', 'success')
    return redirect(url_for('index'))

@app.route('/admin')
def admin():
    if 'role' not in session or session['role'] != 'admin':  # 只有管理员才能访问
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))
    return render_template('admin_index.html')

@app.route('/admin/apprv_post')
def admin_posts():
    if 'role' not in session or session['role'] != 'admin':  # 只有管理员才能访问
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))
    posts = Post.query.filter_by(approved=False).all()
    return render_template('apprv_post.html', posts=posts)

@app.route('/admin/admin_report')
def admin_report():
    reports = RescueReport.query.all()
    
    return render_template('admin_report.html', rescue_reports=reports)

@app.route('/admin/report/action/<int:report_id>/<action>', methods=['POST'])
def handle_report_action(report_id, action):
    report = RescueReport.query.get(report_id)
    if report:
        if action == 'accept':
            report.status = 'Accepted'  # or however you define 'accepted' status
        elif action == 'reject':
            report.status = 'Rejected'  # or however you define 'rejected' status
        
        db.session.commit()
        flash(f'Report has been {action}d.', 'success')
    else:
        flash('Report not found.', 'error')

    return redirect(url_for('admin_report'))

@app.route('/accept_report/<int:report_id>', methods=['POST'])
def accept_report(report_id):
    report = RescueReport.query.get_or_404(report_id)
    # 更新报告状态为已接受
    report.status = 'accepted'
    db.session.commit()
    flash('Report accepted.', 'success')
    return redirect(url_for('admin_report'))

@app.route('/reject_report/<int:report_id>', methods=['POST'])
def reject_report(report_id):
    report = RescueReport.query.get_or_404(report_id)
    # 更新报告状态为已拒绝
    report.status = 'rejected'
    db.session.commit()
    flash('Report rejected.', 'success')
    return redirect(url_for('admin_report'))


@app.route('/admin/volunteers')
def admin_volunteers():
    if 'role' not in session or session['role'] != 'admin':  # 只有管理员才能访问
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))
    volunteer_applications = VolunteerApplication.query.all()
    return render_template('admin_volunteers.html', applications=volunteer_applications)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS

@app.route('/submit', methods=['GET', 'POST'])
def submit_post():
    form = PostForm()
    if form.validate_on_submit():
        name = form.name.data
        phone = form.phone.data
        title = form.title.data
        description = form.description.data
        address = form.address.data
        latitude = form.latitude.data
        longitude = form.longitude.data

        images = request.files.getlist('images')
        image_filenames = []
        for image in images:
            if image and allowed_file(image.filename):
                # 生成唯一的文件名以避免冲突
                filename = f"{uuid.uuid4()}_{secure_filename(image.filename)}"
                image_path = os.path.join(Config.UPLOAD_FOLDER, filename)
                image.save(image_path)
                
                # 创建图片缩略图
                with Image.open(image_path) as img:
                    img.thumbnail((800, 600))
                    img.save(image_path, optimize=True, quality=85)
                
                image_filenames.append(filename)

        # 创建一个新的 Post 对象，并保存数据
        new_post = Post(
            name=name,
            phone=phone,
            title=title,
            description=description,
            address=address,
            latitude=latitude,
            longitude=longitude,
            images=','.join(image_filenames)  # 将文件名存储为逗号分隔的字符串
        )
        db.session.add(new_post)
        db.session.commit()
        flash('帖子提交成功！', 'success')
        return redirect(url_for('index'))

    return render_template('submit.html', form=form)


@app.route('/post/<int:post_id>', methods=['GET'])
def get_post(post_id):
    post = Post.query.get_or_404(post_id)
    print('Database approved value:', post.approved)
    # Handle images
    images = post.images.split(',') if post.images else []
    image_urls = [url_for('static', filename='uploads/' + image) for image in images]
    
    return jsonify({
        'title': post.title,
        'description': post.description,
        'address': post.address,
        'latitude': post.latitude,
        'longitude': post.longitude,
        'approve': post.approved,
        'images': image_urls
    })


@app.route('/post_detail/<int:post_id>')
@login_required
def post_detail(post_id):
    post = Post.query.get_or_404(post_id)
    
    # 检查用户是否有权限访问帖子
    if not current_user.is_authenticated:
        abort(403)  # 用户未登录
    
    # 只有志愿者和管理员可以访问已批准的帖子
    if post.approved and current_user.role in ['volunteer', 'admin']:
        pass
    else:
        abort(403)  # 无权限访问此帖子
    
    post_images = post.images.split(',') if post.images else []
    post_details = {
        'title': post.title,
        'description': post.description,
        'address': post.address,
        'latitude': post.latitude,
        'longitude': post.longitude,
        'images': [url_for('static', filename='uploads/' + img) for img in post_images]
    }
    
    return jsonify(post_details)


@app.route('/approve/<int:post_id>', methods=['POST'])
def approve_post(post_id):
    post = Post.query.get_or_404(post_id)
    post.approved = 1
    db.session.commit()
    return '', 204

@app.route('/reject/<int:post_id>', methods=['POST'])
def reject_post(post_id):
    post = Post.query.get_or_404(post_id)
    post.approved = 2  # 假设 2 表示已拒绝
    db.session.commit()
    return '', 204


@app.route('/done/<int:post_id>', methods=['POST'])
def done_post(post_id):
    post = Post.query.get_or_404(post_id)
    post.approved = 3  # 修改字段名为 approved
    db.session.commit()
    return '', 204


import uuid
from PIL import Image

@app.route('/apply_volunteer', methods=['GET', 'POST'])
@login_required
def apply_volunteer():
    form = VolunteerForm()
    if form.validate_on_submit():
        # 处理文件上传，类似于 submit_post 的方式
        id_card_image = request.files.get('id_card_image')
        selfie_image = request.files.get('selfie_image')

        image_filenames = []
        for image, field_name in [(id_card_image, 'id_card_image'), (selfie_image, 'selfie_image')]:
            if image and allowed_file(image.filename):
                try:
                    filename = f"{uuid.uuid4()}_{secure_filename(image.filename)}"
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    image.save(image_path)

                    # 创建图片缩略图（如果需要）
                    with Image.open(image_path) as img:
                        img.thumbnail((800, 600))  # 调整缩略图大小
                        img.save(image_path, optimize=True, quality=85)

                    image_filenames.append((field_name, filename))  # 将字段名和文件名一起保存
                except Exception as e:
                    app.logger.error(f"Error saving image {field_name}: {e}")
                    flash(f'保存{field_name}时出错，请稍后重试。', 'danger')
                    return render_template('apply_volunteer.html', form=form)
            else:
                flash(f'请上传{field_name}。', 'danger')
                return render_template('apply_volunteer.html', form=form)

        # 创建申请记录
        application = VolunteerApplication(
            user_id=current_user.id,
            real_name=form.real_name.data,
            address=form.address.data,
            phone_number=form.phone_number.data,
            status='Pending'
        )

        # 将图片文件名保存到对应的字段
        for field_name, filename in image_filenames:
            setattr(application, field_name, filename)

        db.session.add(application)
        db.session.commit()

        flash('submited。', 'info')
        return redirect(url_for('index'))  # 或其他合适的页面
    else:
        # 添加调试信息
        app.logger.debug("Form validation failed: {}".format(form.errors))

    # 渲染申请表单
    return render_template('apply_volunteer.html', form=form)

from flask import jsonify, request, redirect, url_for, flash, render_template
from flask_login import current_user

@app.route('/admin/apply_volunteer', methods=['GET', 'POST'])
@admin_required 
def admin_apply_volunteer():
    # 获取待审核申请
    applications = VolunteerApplication.query.filter_by(status='Pending').all()

    if request.method == 'POST':
        # 处理审核操作
        application_id = request.form.get('application_id')
        action = request.form.get('action')
        application = VolunteerApplication.query.get(application_id)
        if application:
            if action == 'approve':
                application.status = 'Approved'
                user = User.query.get(application.user_id)
                if user:
                    user.role = 'volunteer'
                    user.phone_number = application.phone_number
                    user.real_name = application.real_name
            elif action == 'reject':
                application.status = 'Rejected'

            db.session.commit()

            if request.is_xhr:  # 如果是 AJAX 请求
                return jsonify({'status': 'success', 'action': action})

            flash(f'申请已被{action}。', 'info')
            return redirect(url_for('admin_apply_volunteer'))

    # 渲染管理员审核页面
    return render_template('admin_apply_volunteer.html', applications=applications)

@app.route('/volunteer_location', methods=['POST'])
def volunteer_location():
    data = request.get_json()
    latitude = data.get('latitude')
    longitude = data.get('longitude')

    # 获取所有已批准的帖子
    posts = Post.query.filter_by(approved=True).all()

    # 如果有地理位置，计算距离并获取最近的帖子
    if latitude and longitude:
        user_location = (latitude, longitude)
        posts = sorted(posts, key=lambda post: geodesic(user_location, (post.latitude, post.longitude)).km)
        posts = posts[:10]  # 取最近的10个帖子

    return jsonify([{
        'id': post.id,
        'title': post.title,
        'description': post.description,
        'images': post.images,
        'latitude': post.latitude,
        'longitude': post.longitude
    } for post in posts])

@app.route('/latest_posts', methods=['GET'])
def latest_posts():
    posts = Post.query.filter_by(approved=True).order_by(Post.date_posted.desc()).limit(10).all()
    return jsonify([{
        'id': post.id,
        'title': post.title,
        'description': post.description,
        'images': post.images,
        'latitude': post.latitude,
        'longitude': post.longitude
    } for post in posts])

@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return '', 204

@app.route('/downgrade_user/<int:user_id>', methods=['POST'])
def downgrade_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == 'volunteer':
        user.role = 'user'
        db.session.commit()
    return '', 204

@app.route('/profile')
@login_required
def profile():
    # 这里可以处理从数据库获取用户信息的逻辑
    return render_template('AccProfile.html')

@app.route('/report', methods=['GET', 'POST'])
@login_required
def report():
    default_title = request.args.get('post_title', '')

    if request.method == 'POST':
        # 获取表单数据
        title = request.form.get('title')
        name = request.form.get('name')
        phone = request.form.get('phone')
        injured_part = request.form.get('injured_part')
        rescue_method = request.form.get('rescue_method')
        after_rescuing = request.form.get('after_rescuing')
        process = request.form.get('process')

        print(f"Title: {title}")
        print(f"Name: {name}")
        print(f"Phone: {phone}")
        print(f"Injured Part: {injured_part}")
        print(f"Rescue Method: {rescue_method}")
        print(f"After Rescuing: {after_rescuing}")
        print(f"Process: {process}")

        # 检查必填字段
        if not title or not name or not phone or not injured_part:
            flash('Please fill in all required fields.', 'error')
            return redirect(url_for('report'))

        # 处理上传的图片
        images = request.files.getlist('images')
        print(f"Uploaded images: {images}")  # 添加调试信息
        if not images:
            print("No images uploaded.")
        image_filenames = []
        for image in images:
            print(f"Processing file: {image.filename}")  # 添加调试信息
            if image and allowed_file(image.filename):
                filename = f"{uuid.uuid4()}_{secure_filename(image.filename)}"
                image_path = os.path.join(Config.UPLOAD_FOLDER, filename)
                image.save(image_path)
                
                print(f"Saving image to: {image_path}")

                # 创建图片缩略图
                with Image.open(image_path) as img:
                    img.thumbnail((800, 600))
                    img.save(image_path, optimize=True, quality=85)

                image_filenames.append(filename)
            else:
                print(f"Skipped file: {image.filename}")

        print(f"Image Filenames: {image_filenames}")

        # 创建并保存救援报告
        new_report = RescueReport(
            title=title,
            name=name,
            phone=phone,
            injured_part=injured_part,
            rescue_method=rescue_method,
            after_rescuing=after_rescuing,
            process=process,
            images=','.join(image_filenames)
        )
        db.session.add(new_report)
        db.session.commit()

        flash('Rescue report and images uploaded successfully!', 'success')
        return redirect(url_for('index'))

    # GET 请求时显示报告上传表单和已提交的报告
    posts = Post.query.all()
    reports = RescueReport.query.all()
    return render_template('Reports.html', reports=reports, posts=posts, current_user=current_user, default_title=default_title)

@app.route('/contact', methods=['POST'])
def contact():
    name = request.form['name']
    email = request.form['email']
    
    message = request.form['message']
    
    # 创建并保存 Contact 实例到数据库
    new_contact = Contact(name=name, email=email, message=message)
    db.session.add(new_contact)
    db.session.commit()
    
    return redirect(url_for('index'))


@app.route('/admin/contact')
def admin_contact():
    if 'role' not in session or session['role'] != 'admin':  # 只有管理员才能访问
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))
    
    contacts = Contact.query.all()  # 查询所有联系记录
    return render_template('admin_contact.html', contacts=contacts)

@app.route('/admin/contact/complete/<int:contact_id>', methods=['POST'])
def complete_contact(contact_id):
    contact = db.session.get(Contact, contact_id)
    if contact:
        db.session.delete(contact)
        db.session.commit()
        return '', 200  # 返回成功状态码
    return '', 404  # 返回未找到状态码

@app.route('/admin/admin_post')
def admin_post():
    if 'role' not in session or session['role'] != 'admin':  # 只有管理员才能访问
        flash('您没有权限访问此页面。', 'danger')
        return redirect(url_for('index'))
    posts = Post.query.filter_by(approved=True).all()
    return render_template('apprv_post.html', posts=posts)

    
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 创建数据库表
    app.run(host='0.0.0.0', port=5000, debug=True)  # 启动 Flask 应用
